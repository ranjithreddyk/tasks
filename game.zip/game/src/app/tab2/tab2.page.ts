import { Component } from '@angular/core';
declare var RazorpayCheckout: any;

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  currency: any;
  razor_key: any;
  totalPrice: any;

  constructor() {}
  payWithRazor() {
    var options = {
      description: 'Credits towards consultation',
      image: 'https://i.imgur.com/3g7nmJC.png',
      currency: this.currency, // your 3 letter currency code
      key: this.razor_key, // your Key Id from Razorpay dashboard
      amount: this.totalPrice, // Payment amount in smallest denomiation e.g. cents for USD
      name: 'foo',
      prefill: {
        email: 'admin@enappd.com',
        contact: '9621323231',
        name: 'Enappd'
      },
      theme: {
        color: '#F37254'
      },
      modal: {
        ondismiss: function () {
          alert('dismissed')
        }
      }
    };

    var successCallback = function (payment_id) {
      alert('payment_id: ' + payment_id);
        
    this. Json_Inst={
   
     
      
      "userId" : this.userId ,
      "cartId" : this.cartId,
      "address" : this.address ,
      "categoryId":this.categoryId,
      "productId":this.productId
      
      
  
      }
      console.log(this.Json_Inst);
      
 this.api.postDataWithToken("orders",this.Json_Inst ).subscribe(
    (res: any) => {
      console.log(res);
    
   this.router.navigate(['eco-success']);
    
 
});
    };

    var cancelCallback = function (error) {
      alert(error.description + ' (Error ' + error.code + ')');
    };

    RazorpayCheckout.open(options, successCallback, cancelCallback);
  }
}