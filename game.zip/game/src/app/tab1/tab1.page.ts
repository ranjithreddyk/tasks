import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../tabs/services/api.service';
import { UtilService } from '../tabs/services/util.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  @ViewChild('barChart') barChart;   
  interval: any;
  async helloWorld() {
    console.log("Before delay!")
    await delay(500)
    console.log("After delay\nHello World Async!")
  } 
  alive:boolean;
  alive0:boolean;alive0100:boolean;alive0110:boolean;
  alive1:boolean;alive1040:boolean;
  alive2:boolean;
  alive02:boolean;
  alive002:boolean;
  alive3:boolean;alive03:boolean;alive030:boolean;alive0030:boolean;
  alive4:boolean;alive040:boolean;
  alive04:boolean;
  alive004:boolean;alive0040:boolean;
  alive0004:boolean;
  alive00004:boolean;
  alive5:boolean;
  alive05:boolean;
  alive005:boolean;
  alive0005:boolean;
  alive6:boolean;alive606:boolean;
  alive7:boolean;alive070:boolean;alive789:boolean;
  alive07:boolean;
  alive007:boolean;
  alive8:boolean;alive080:boolean;
  alive9:boolean;alive987:boolean;alive905:boolean;
  alive10:boolean;
  alive100:boolean;alive00100:boolean;
  alive1000:boolean;
  alive10000:boolean;
  alive100000:boolean;
  alive11:boolean;
  alive111:boolean;
  alive1111:boolean;
  alive11111:boolean;
  alive15:boolean;
  alive16:boolean;
  alive12:boolean;
  alive13:boolean;
  alive130:boolean;
  alive131:boolean;
  alive14:boolean;
  alive17:boolean;
  alive18:boolean;
  alive19:boolean;
  alive20:boolean;
  alive21:boolean;
  alive22:boolean;
  alive23:boolean;
  alive24:boolean;
  alive240:boolean;
  alive27:boolean;
  alive28:boolean;
  alive280:boolean;
  alive29:boolean;
  alive30:boolean;
  alive31:boolean;
  alive25:boolean;
  alive250:boolean;
  alive26:boolean;
  alive260:boolean;
  alive261:boolean;
  alive32:boolean;
  alive33:boolean;
  alive330:boolean;
  alive331:boolean;
  alive34:boolean;
  alive35:boolean;
  alive36:boolean;
  alive37:boolean;
  alive38:boolean;alive380:boolean;
  alive39:boolean;alive390:boolean;alive391:boolean;
  alive40:boolean;
  alive41:boolean;
  alive42:boolean;
  alive43:boolean;
  alive44:boolean;
  alive45:boolean;
  alive46:boolean;
  alive47:boolean;
  alive48:boolean;
  alive49:boolean;
  alive50:boolean;
  alive51:boolean;
  alive52:boolean;
  alive53:boolean;
  alive54:boolean;
  alive55:boolean;
  alive56:boolean;
  alive57:boolean;alive570:boolean;
  alive58:boolean;
  alive59:boolean;alive590:boolean;
  alive60:boolean;alive600:boolean;
  alive61:boolean;alive610:boolean;alive611:boolean;
  alive62:boolean;
  alive63:boolean;
  alive64:boolean;
  alive65:boolean;
  alive66:boolean;
  alive67:boolean;alive670:boolean;alive671:boolean;
  alive68:boolean;
  alive69:boolean;alive690:boolean;alive691:boolean;
  alive70:boolean;
  alive71:boolean;
  alive72:boolean;
  alive73:boolean;
  alive74:boolean;
  alive75:boolean;
  alive76:boolean;
  alive77:boolean;
  alive78:boolean;
  alive79:boolean;
  alive80:boolean;
  alive01:boolean;
  alive001:boolean;alive0011:boolean;
  alive0001:boolean;
  alive00001:boolean;
  alive000001:boolean;
  bars: any;
  colorArray: any;
  userId: any;
  sbt: any;
  yes: any;
  no: any;
  
  isReadonly:boolean;
  item:any;
  item1:any;
  item2:any;
  item3:any;
  item4:any;
  item5:any;
  pop: any;
  age: any;
  age1:any;
  
  
  
  constructor(private util: UtilService,private router: Router,
    private api: ApiService,) { }
  
  ngOnInit() {
    this.item= "";
    this.item1= "";
    this.item3= "";
    this.item2= "";
    this.item4= "";
    this.item5= "";
    
    this.api.userToken=localStorage.getItem("access_token");
    console.log( this.api.userToken);
    this.userId=localStorage.getItem("userId");
    console.log( this.userId);
  this.po3p();
  this.po3p1();  
  this.po3p3();
  this.po3p2();
  this.po3p4();
  this.po3p5();
  }
  postevent(){
    let Json_data= {
      "userId": this.userId,
    "formvalue":this.item
      }
  console.log(Json_data);
    let endpoint="addChatBot"
    this.api.postDataWithToken(endpoint,Json_data).subscribe(
      (res: any) => {
        console.log(res);
        // console.log(res.products);
        // this.products  = res.products
      })
  }
  postevent1(){
    let Json_data= {
      "userId": this.userId,
    "formvalue":this.item1
      }
  console.log(Json_data);
    let endpoint="addChatBot"
    this.api.postDataWithToken(endpoint,Json_data).subscribe(
      (res: any) => {
        console.log(res);
        // console.log(res.products);
        // this.products  = res.products
      })
  }
  postevent2(){
    let Json_data= {
      "userId": this.userId,
    "formvalue":this.item2
      }
  console.log(Json_data);
    let endpoint="addChatBot"
    this.api.postDataWithToken(endpoint,Json_data).subscribe(
      (res: any) => {
        console.log(res);
        // console.log(res.products);
        // this.products  = res.products
      })
  }
  postevent3(){
    let Json_data= {
      "userId": this.userId,
    "formvalue":this.item3
      }
  console.log(Json_data);
    let endpoint="addChatBot"
    this.api.postDataWithToken(endpoint,Json_data).subscribe(
      (res: any) => {
        console.log(res);
        // console.log(res.products);
        // this.products  = res.products
      })
  }
  postevent4(){
    let Json_data= {
      "userId": this.userId,
    "formvalue":this.item4
      }
  console.log(Json_data);
    let endpoint="addChatBot"
    this.api.postDataWithToken(endpoint,Json_data).subscribe(
      (res: any) => {
        console.log(res);
        // console.log(res.products);
        // this.products  = res.products
      })
  }
  postevent5(){
    let Json_data= {
      "userId": this.userId,
    "formvalue":this.item5
      }
  console.log(Json_data);
    let endpoint="addChatBot"
    this.api.postDataWithToken(endpoint,Json_data).subscribe(
      (res: any) => {
        console.log(res);
        // console.log(res.products);
        // this.products  = res.products
      })
  }
  ionViewDidEnter() {
    // this.createBarChart();
  }
  
  hyy()
  {
    console.log("hyy");
    this.interval = setInterval(() => {
        this.alive0=true  
      // console.log("Do stuff...")  
  
      }, 1000); 
    console.log("hyy");
    this.interval = setInterval(() => {
        this.alive=true  
      // console.log("Do stuff...")  
  
      }, 3500); 
      console.log("hyy");
    this.interval = setInterval(() => {
        this.alive01=true  
      // console.log("Do stuff...")  
  
      }, 7300); 
      console.log("hyy");
      this.interval = setInterval(() => {
          this.alive001=true  
        // console.log("Do stuff...")  
  
        }, 9900);
  
  }
  hyy1()
  {
    console.log("hyy1");
    this.interval = setInterval(() => {
        this.alive0011=true  
      // console.log("Do stuff...")  
  
      }, 500);
    console.log("hyy1");
    this.interval = setInterval(() => {
        this.alive0001=true  
      // console.log("Do stuff...")  
  
      }, 7300); 
      console.log("hyy1");
    this.interval = setInterval(() => {
        this.alive00001=true  
      // console.log("Do stuff...")  
  
      }, 9900); 
      console.log("hyy1");
      this.interval = setInterval(() => {
          this.alive000001=true  
        // console.log("Do stuff...")  
  
        }, 12000);
  
  }
  hyy2()
  { 
  
    console.log("hyy2");
    this.interval = setInterval(() => {
        this.alive2=true  
      // console.log("Do stuff...")  
  
      }, 500); 
      console.log("hyy2");
      this.interval = setInterval(() => {
          this.alive02=true  
        // console.log("Do stuff...")  
    
        }, 1000); 
        console.log("hyy2");
        this.interval = setInterval(() => {
            this.alive002=true  
          // console.log("Do stuff...")  
      
          }, 3500); 
    
  
  }
  hyy3()
  { 
    console.log("hyy3");
    this.interval = setInterval(() => {
        this.alive789=true  
      // console.log("Do stuff...")  
  
      }, 500);
    console.log("hyy3");
    this.interval = setInterval(() => {
        this.alive040=true  
      // console.log("Do stuff...")  
  
      }, 1000);
    console.log("hyy3");
    this.interval = setInterval(() => {
        this.alive4=true  
      // console.log("Do stuff...")  
  
      }, 3500);
    console.log("hyy3");
    this.interval = setInterval(() => {
        this.alive04=true  
      // console.log("Do stuff...")  
  
      }, 7300); 
      console.log("hyy3");
    this.interval = setInterval(() => {
        this.alive004=true  
      // console.log("Do stuff...")  
  
      }, 9900); 
      console.log("hyy3");
      this.interval = setInterval(() => {
          this.alive0004=true  
        // console.log("Do stuff...")  
  
        }, 12000);
        console.log("hyy3");
        this.interval = setInterval(() => {
            this.alive00004=true  
          // console.log("Do stuff...")  
    
          }, 15000);
  
  }
  hyy4()
  {
    console.log("hyy4");
    this.interval = setInterval(() => {
        this.alive5=true  
      // console.log("Do stuff...")  
  
      }, 3500);
    console.log("hyy4");
    this.interval = setInterval(() => {
        this.alive05=true  
      // console.log("Do stuff...")  
  
      }, 7300); 
      console.log("hyy4");
    this.interval = setInterval(() => {
        this.alive005=true  
      // console.log("Do stuff...")  
  
      }, 9900); 
      console.log("hyy4");
      this.interval = setInterval(() => {
          this.alive0005=true  
        // console.log("Do stuff...")  
  
        }, 12000);
  
  }
  hyy5()
  {
    console.log("hyy5");
    this.interval = setInterval(() => {
        this.alive987=true  
      // console.log("Do stuff...")  
  
      }, 500);
    console.log("hyy5");
    this.interval = setInterval(() => {
        this.alive030=true  
      // console.log("Do stuff...")  
  
      }, 1000);
    console.log("hyy5");
    this.interval = setInterval(() => {
        this.alive3=true  
      // console.log("Do stuff...")  
  
      }, 3500); 
      console.log("hyy5");
      this.interval = setInterval(() => {
          this.alive03=true  
        // console.log("Do stuff...")  
  
        }, 5300);
    
  
  }
  hyy6()
  {
    console.log("hyy6");
    this.interval = setInterval(() => {
        this.alive606=true  
      // console.log("Do stuff...")  
  
      }, 1000);
    console.log("hyy6");
    this.interval = setInterval(() => {
        this.alive6=true  
      // console.log("Do stuff...")  
  
      }, 3500); 
     
    
  
  }
  hyy7()
  {
    console.log("hyy7");
    this.interval = setInterval(() => {
        this.alive070=true  
      // console.log("Do stuff...")  
  
      }, 1000);
    console.log("hyy7");
    this.interval = setInterval(() => {
        this.alive7=true  
      // console.log("Do stuff...")  
  
      }, 3500); 
      console.log("hyy7");
      this.interval = setInterval(() => {
          this.alive07=true  
        // console.log("Do stuff...")  
  
        }, 7300);
        console.log("hyy7");
        this.interval = setInterval(() => {
            this.alive007=true  
          // console.log("Do stuff...")  
    
          }, 9900);
    
  
  }
  hyy8(){
    console.log("hyy8");
  this.interval = setInterval(() => {
      this.alive080=true  
    // console.log("Do stuff...")  
  
    }, 1000);
    console.log("hyy8");
  this.interval = setInterval(() => {
      this.alive8=true  
    // console.log("Do stuff...")  
  
    }, 3500);
  }
  hyy9(){
    console.log("hyy9");
  this.interval = setInterval(() => {
      this.alive905=true  
    // console.log("Do stuff...")  
  
    }, 500);
    console.log("hyy9");
  this.interval = setInterval(() => {
      this.alive9=true  
    // console.log("Do stuff...")  
  
    }, 3500);
  }
  
  hyy10(){
    
    console.log("hyy10");
  this.interval = setInterval(() => {
      this.alive0110=true  
    // console.log("Do stuff...")  
  
    }, 1000);
    console.log("hyy10");
  this.interval = setInterval(() => {
      this.alive11=true  
    // console.log("Do stuff...")  
  
    }, 3500);
    console.log("hyy10");
  this.interval = setInterval(() => {
      this.alive111=true  
    // console.log("Do stuff...")  
  
    }, 7300);
    console.log("hyy10");
  this.interval = setInterval(() => {
      this.alive1111=true  
    // console.log("Do stuff...")  
  
    }, 9900);
    console.log("hyy10");
  this.interval = setInterval(() => {
      this.alive11111=true  
    // console.log("Do stuff...")  
  
    }, 12000);
  
  }
  hyy11(){
    
    console.log("hyy11");
  this.interval = setInterval(() => {
      this.alive0100=true  
    // console.log("Do stuff...")  
  
    }, 1000);
    console.log("hyy11");
  this.interval = setInterval(() => {
      this.alive10=true  
    // console.log("Do stuff...")  
  
    }, 3500);
    console.log("hyy11");
  this.interval = setInterval(() => {
      this.alive100=true  
    // console.log("Do stuff...")  
  
    }, 7300);
    console.log("hyy11");
  this.interval = setInterval(() => {
      this.alive1000=true  
    // console.log("Do stuff...")  
  
    }, 9900);
    console.log("hyy11");
  this.interval = setInterval(() => {
      this.alive10000=true  
    // console.log("Do stuff...")  
  
    }, 12000);
    console.log("hyy11");
    this.interval = setInterval(() => {
        this.alive100000=true  
      // console.log("Do stuff...")  
  
      }, 15000);
  
  }
  
  hyy12(){
    console.log("hyy12");
    this.interval = setInterval(() => {
        this.alive1040=true  
      // console.log("Do stuff...")  
    
      }, 500);
  
    console.log("hyy12");
    this.interval = setInterval(() => {
        this.alive00100=true  
      // console.log("Do stuff...")  
    
      }, 1000);
    console.log("hyy12");
  this.interval = setInterval(() => {
      this.alive40=true  
    // console.log("Do stuff...")  
  
    }, 3500);
  }
  hyy13(){
    console.log("hyy13");
  this.interval = setInterval(() => {
      this.alive13=true  
    // console.log("Do stuff...")  
  
    }, 3500);
    console.log("hyy13");
    this.interval = setInterval(() => {
        this.alive130=true  
      // console.log("Do stuff...")  
  
      }, 3500);
      console.log("hyy13");
      this.interval = setInterval(() => {
          this.alive131=true  
        // console.log("Do stuff...")  
    
        }, 3500);
  }
  hyy14(){
    console.log("hyy14");
  this.interval = setInterval(() => {
      this.alive12=true  
    // console.log("Do stuff...")  
  
    }, 3500);}
    hyy15(){
      console.log("hyy15");
    this.interval = setInterval(() => {
        this.alive17=true  
      // console.log("Do stuff...")  
  
      }, 3500);}
      
            hyy16(){
              console.log("hyy16");
            this.interval = setInterval(() => {
                this.alive18=true  
              // console.log("Do stuff...")  
          
              }, 3500);}
              hyy17(){
                console.log("hyy17");
              this.interval = setInterval(() => {
                  this.alive20=true  
                // console.log("Do stuff...")  
            
                }, 3500);}
                hyy18(){
                  console.log("hyy18");
                this.interval = setInterval(() => {
                    this.alive21=true  
                  // console.log("Do stuff...")  
              
                  }, 3500);}
                  hyy19(){
                    console.log("hyy19");
                  this.interval = setInterval(() => {
                      this.alive22=true  
                    // console.log("Do stuff...")  
                
                    }, 3500);}
                    hyy20(){
                      console.log("hyy20");
                    this.interval = setInterval(() => {
                        this.alive23=true  
                      // console.log("Do stuff...")  
                  
                      }, 3500);}
                      hyy21(){
                        console.log("hyy21");
                      this.interval = setInterval(() => {
                          this.alive24=true  
                        // console.log("Do stuff...")  
                    
                        }, 3500);
                    
                          console.log("hyy21");
                        this.interval = setInterval(() => {
                            this.alive240=true  
                          // console.log("Do stuff...")  
                      
                          }, 7300);}
                          hyy22(){
                            console.log("hyy22");
                          this.interval = setInterval(() => {
                              this.alive25=true  
                            // console.log("Do stuff...")  
                        
                            }, 3500);
                        
                              console.log("hyy22");
                            this.interval = setInterval(() => {
                                this.alive250=true  
                              // console.log("Do stuff...")  
                          
                              }, 7300);}
                              hyy23(){
                                console.log("hyy23");
                              this.interval = setInterval(() => {
                                  this.alive27=true  
                                // console.log("Do stuff...")  
                            
                                }, 3500);
                              }  
                              hyy24(){
                                console.log("hyy24");
                              this.interval = setInterval(() => {
                                  this.alive26=true  
                                // console.log("Do stuff...")  
                            
                                }, 3500);
                                console.log("hyy24");
                                this.interval = setInterval(() => {
                                    this.alive260=true  
                                  // console.log("Do stuff...")  
                              
                                  }, 7300);
                                  console.log("hyy24");
                                  this.interval = setInterval(() => {
                                      this.alive261=true  
                                    // console.log("Do stuff...")  
                                
                                    }, 9900);
                              }  
                              hyy25(){
                                console.log("hyy25");
                              this.interval = setInterval(() => {
                                  this.alive28=true  
                                // console.log("Do stuff...")  
                            
                                }, 3500);
                                console.log("hyy25");
                                this.interval = setInterval(() => {
                                    this.alive280=true  
                                  // console.log("Do stuff...")  
                              
                                  }, 7300);
                                  }
                                  hyy26(){
                                    console.log("hyy26");
                                  this.interval = setInterval(() => {
                                      this.alive29=true  
                                    // console.log("Do stuff...")  
                                
                                    }, 3500);}
                                    hyy27(){
                                      console.log("hyy27");
                                    this.interval = setInterval(() => {
                                        this.alive30=true  
                                      // console.log("Do stuff...")  
                                  
                                      }, 3500);}
  hyy28(){
   console.log("hyy28");
    this.interval = setInterval(() => {
      this.alive33=true  
        // console.log("Do stuff...")  
        }, 3500);
        console.log("hyy28");
        this.interval = setInterval(() => {
          this.alive330=true  
            // console.log("Do stuff...")  
            }, 7300);
            console.log("hyy28");
            this.interval = setInterval(() => {
              this.alive331=true  
                // console.log("Do stuff...")  
                }, 9900);
      }
      hyy29(){
        console.log("hyy29");
         this.interval = setInterval(() => {
           this.alive34=true  
             // console.log("Do stuff...")  
             }, 3500);
           
           }
           hyy30(){
            console.log("hyy30");
             this.interval = setInterval(() => {
               this.alive35=true  
                 // console.log("Do stuff...")  
                 }, 3500);
               
               }  
               hyy31(){
                console.log("hyy3");
                 this.interval = setInterval(() => {
                   this.alive36=true  
                     // console.log("Do stuff...")  
                     }, 3500);
                   
                   }  
                   hyy32(){
                    console.log("hyy32");
                     this.interval = setInterval(() => {
                       this.alive37=true  
                         // console.log("Do stuff...")  
                         }, 3500);
                       
                       }  
                       hyy33(){
                        console.log("hyy33");
                         this.interval = setInterval(() => {
                           this.alive38=true  
                             // console.log("Do stuff...")  
                             }, 3500);
                             console.log("hyy33");
                             this.interval = setInterval(() => {
                               this.alive380=true  
                                 // console.log("Do stuff...")  
                                 }, 7300);
                           
                           }
                           hyy34(){
                            console.log("hyy34");
                             this.interval = setInterval(() => {
                               this.alive39=true  
                                 // console.log("Do stuff...")  
                                 }, 3500);
                                 console.log("hyy34");
                                 this.interval = setInterval(() => {
                                   this.alive390=true  
                                     // console.log("Do stuff...")  
                                     }, 7300);
                                     console.log("hyy34");
                                     this.interval = setInterval(() => {
                                       this.alive391=true  
                                         // console.log("Do stuff...")  
                                         }, 9900); 
                               }  
                               hyy35(){
                                console.log("hyy35");
                                 this.interval = setInterval(() => {
                                   this.alive43=true  
                                     // console.log("Do stuff...")  
                                     }, 3500); }
                                     hyy36(){
                                      console.log("hyy36");
                                       this.interval = setInterval(() => {
                                         this.alive44=true  
                                           // console.log("Do stuff...")  
                                           }, 3500);}
                                           hyy37(){
                                            console.log("hyy37");
                                             this.interval = setInterval(() => {
                                               this.alive45=true  
                                                 // console.log("Do stuff...")  
                                                 }, 3500);}
                                                 hyy38(){
                                                  console.log("hyy38");
                                                   this.interval = setInterval(() => {
                                                     this.alive46=true  
                                                       // console.log("Do stuff...")  
                                                       }, 3500);}
                                                       hyy39(){
                                                        console.log("hyy39");
                                                         this.interval = setInterval(() => {
                                                           this.alive48=true  
                                                             // console.log("Do stuff...")  
                                                             }, 9900);}
  hyy40(){
  console.log("hyy40");
  this.interval = setInterval(() => {
  this.alive49=true  
  // console.log("Do stuff...")  
  }, 9900);}
  hyy41(){
  console.log("hyy41");
  this.interval = setInterval(() => {
  this.alive50=true  
  // console.log("Do stuff...")  
  }, 3500);}
  hyy42(){
    console.log("hyy42");
    this.interval = setInterval(() => {
    this.alive51=true  
    // console.log("Do stuff...")  
    }, 3500);}
    hyy43(){
      console.log("hyy43");
      this.interval = setInterval(() => {
      this.alive52=true  
      // console.log("Do stuff...")  
      }, 3500);}
      hyy49(){
        console.log("hyy49");
        this.interval = setInterval(() => {
        this.alive58=true  
        // console.log("Do stuff...")  
        }, 3500);}
        hyy50(){
          console.log("hyy50");
          this.interval = setInterval(() => {
          this.alive59=true  
          // console.log("Do stuff...")  
          }, 3500);
          console.log("hyy50");
          this.interval = setInterval(() => {
          this.alive590=true  
          // console.log("Do stuff...")  
          }, 7300);
        }
        hyy51(){
          console.log("hyy51");
          this.interval = setInterval(() => {
          this.alive60=true  
          // console.log("Do stuff...")  
          }, 3500);
          console.log("hyy51");
          this.interval = setInterval(() => {
          this.alive600=true  
          // console.log("Do stuff...")  
          }, 7300);
        }
        hyy52(){
          console.log("hyy52");
          this.interval = setInterval(() => {
          this.alive61=true  
          // console.log("Do stuff...")  
          }, 3500);
          console.log("hyy52");
          this.interval = setInterval(() => {
          this.alive610=true  
          // console.log("Do stuff...")  
          }, 7300);
          console.log("hyy52");
          this.interval = setInterval(() => {
          this.alive610=true  
          // console.log("Do stuff...")  
          }, 9900);
        }
        hyy53(){
          console.log("hyy53");
          this.interval = setInterval(() => {
          this.alive62=true  
          // console.log("Do stuff...")  
          }, 3500);
          
        }
        hyy54(){
          console.log("hyy54");
          this.interval = setInterval(() => {
          this.alive63=true  
          // console.log("Do stuff...")  
          }, 3500);
          
        }
        hyy55(){
          console.log("hyy55");
          this.interval = setInterval(() => {
          this.alive64=true  
          // console.log("Do stuff...")  
          }, 3500);
          
        }
        hyy56(){
          console.log("hyy56");
          this.interval = setInterval(() => {
          this.alive65=true  
          // console.log("Do stuff...")  
          }, 3500);
          
        }
        hyy57(){
          console.log("hyy57");
          this.interval = setInterval(() => {
          this.alive66=true  
          // console.log("Do stuff...")  
          }, 3500);
          
        }
        hyy58(){
          console.log("hyy58");
          this.interval = setInterval(() => {
          this.alive67=true  
          // console.log("Do stuff...")  
          }, 3500);
          console.log("hyy58");
          this.interval = setInterval(() => {
          this.alive670=true  
          // console.log("Do stuff...")  
          },7300);
          console.log("hyy58");
          this.interval = setInterval(() => {
          this.alive671=true  
          // console.log("Do stuff...")  
          }, 9900);
          
        }
        hyy59(){
          console.log("hyy59");
          this.interval = setInterval(() => {
          this.alive68=true  
          // console.log("Do stuff...")  
          }, 3500);
          
        }
        hyy60(){
          console.log("hyy60");
          this.interval = setInterval(() => {
          this.alive69=true  
          // console.log("Do stuff...")  
          }, 3500);
          console.log("hyy60");
          this.interval = setInterval(() => {
          this.alive690=true  
          // console.log("Do stuff...")  
          }, 7300);
          console.log("hyy60");
          this.interval = setInterval(() => {
          this.alive691=true  
          // console.log("Do stuff...")  
          }, 9900);
          
        }
  
        hyy44(){
          console.log("hyy44");
          this.interval = setInterval(() => {
          this.alive53=true  
          // console.log("Do stuff...")  
          }, 3500);
          
        }
        hyy45(){
          console.log("hyy45");
          this.interval = setInterval(() => {
          this.alive54=true  
          // console.log("Do stuff...")  
          }, 3500);
          
        }
        hyy46(){
          console.log("hyy46");
          this.interval = setInterval(() => {
          this.alive55=true  
          // console.log("Do stuff...")  
          }, 3500);
          
        }
        hyy47(){
          console.log("hyy47");
          this.interval = setInterval(() => {
          this.alive56=true  
          // console.log("Do stuff...")  
          }, 3500);
          
        }
        hyy48(){
          console.log("hyy48");
          this.interval = setInterval(() => {
          this.alive57=true  
          // console.log("Do stuff...")  
          }, 3500);
          console.log("hyy48");
          this.interval = setInterval(() => {
          this.alive570=true  
          // console.log("Do stuff...")  
          }, 7300);
          
        }
  
  
  
  
  
  // createBarChart() {
  //   this.bars = new chat(this.barChart.nativeElement, {
  //     type: 'bar',
  //     data: {
  //       labels: ['underweight', 'normal', 'overweight', 'obesity'],
  //       datasets: [{
  //         label: 'Yes',
  //         data: [2, 3, 1, 5],
  //         backgroundColor: '#00ff8c', // array should have same number of elements as number of dataset
  //         borderColor: '#00ff8c',// array should have same number of elements as number of dataset
  //         borderWidth: 1,
          
  
  //       },
  //       {
  //         label: 'No',
  //         data: [1, 3, 4, 3],
  //         backgroundColor: '#f70000', // array should have same number of elements as number of dataset
  //         borderColor: '#f70000',// array should have same number of elements as number of dataset
  //         borderWidth: 1
  //       }]
  //     },
  //     options: {
  //       scales: {
  //         yAxes: [{
  //           ticks: {
  //             beginAtZero: true
  //           }
  //         }]
  //       }
  //     }
  //   });
  
  //   }
  
  
  
  
  ranj(){
      this.router.navigateByUrl("sbt")
    }
  po3p(){
  console.log(this.item);
  
  }
  po3p1(){
  console.log(this.item);
  
  }
  po3p3(){
    console.log(this.item);
    
    }
    po3p2(){
      console.log(this.item);
      
      }
      po3p4(){
        console.log(this.item);
        
        }
        po3p5(){
          console.log(this.item);
          
          }
  
  public ageFromDOB(dateOfBirth) {
  console.log(dateOfBirth.detail.value);
  
  
  const today = new Date();
  const birthdate = new Date(dateOfBirth.detail.value);
  console.log(today.getFullYear());
  
  console.log(today);
  console.log(birthdate);
  
  console.log(birthdate.getFullYear());
  
  
  this.age = today.getFullYear() - birthdate.getFullYear();
  const month = today.getMonth() - birthdate.getMonth();
  if ( month < 0 || (month === 0 && today.getDate() < birthdate.getDate())) {
    this.age--;
  }
  console.log(this.age);
  
  
   let age1=this.age
    localStorage.setItem("age",age1)
    let pop=localStorage.getItem("age")
    console.log(pop);
    if(this.pop<=18){
      console.log("above 18");
  // this.alive2=true;
      
    }
    else(this.pop>=18);{
      console.log("below 18");
      // this.alive2=true;
    }
           
  
  }
  
  
  updateMyDate($event) {
  const day: number = $event.detail.value.day.value;
  const month: number = $event.detail.value.month.value;
  const year: number = $event.detail.value.year.value;
  // console.log(day+month+year);
  
  }}
  
  function elseif(arg0: boolean) {
  throw new Error('Function not implemented.');
  }
  function getquestionsdatA() {
  throw new Error('Function not implemented.');
  }

function delay(arg0: number) {
  throw new Error('Function not implemented.');
}
