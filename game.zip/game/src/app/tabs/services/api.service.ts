// import { environment } from './../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
const httpOptions = {
  headers: new HttpHeaders({
    // "Content-Type": "application/json",
    // "Access-Control-Allow-Origin": "*",
    // "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,PATCH,OPTIONS"
  })
};
@Injectable({
  providedIn: 'root',
})
export class ApiService {
  baseUrl='http://tarawithyou.com/api/';
  category: any;
  userToken: any;
  deviceToken: any;
  verifyMo: any;
  // tslint:disable-next-line:variable-name
  phone_no: any;
  // tslint:disable-next-line:variable-name
  email_id: any;
  userReferalCode: any;
  hotelReferalCode: any;
  id: any;
  bookid: any;
  time: any = {};
  categoryId: any;
  branchId: any;
  empId: any;
  serviceTypeId: any;
  serviceId: any;
  msg;
  custName: any;
  customersData: any = {};
  filterData; // bunty code
  hasReferalCode: any;
  donationAmount: number;
  constructor(private http: HttpClient) {
    if (localStorage.getItem('token')) {
      this.userToken = localStorage.getItem('token');
    }
  }
  getData(url) {
    return this.http.get(this.baseUrl + url,httpOptions);
  }
  postData(url, data) {
    return this.http.post(this.baseUrl + url, data,httpOptions);
  }

  getDataWithToken(url) {
    console.log(url);
    console.log(this.userToken);
    
    let header = new HttpHeaders();
    header = header.set('Authorization', 'Bearer ' + this.userToken);
    header = header.set('Accept', 'application/json');
    return this.http.get(this.baseUrl + url, { headers: header });
  }
  getDataWithToken1(url,data) {
    console.log(data);
    console.log(this.userToken);
    
    let header = new HttpHeaders();
    header = header.set('Authorization', 'Bearer ' + this.userToken);
    header = header.set('Accept', 'application/json');
    return this.http.post(this.baseUrl + url,data, { headers: header });
  }
  postDataWithToken(url, data) {
    console.log(data);
    console.log(this.userToken);
    
    let header = new HttpHeaders();
    header = header.set('Authorization', 'Bearer ' + this.userToken);
    header = header.set('Accept', 'application/json');
    return this.http.post(this.baseUrl + url, data, { headers: header });
  }
}