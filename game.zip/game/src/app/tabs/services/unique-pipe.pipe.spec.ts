import { UniquePipePipe } from './unique-pipe.pipe';

describe('UniquePipePipe', () => {
  it('create an instance', () => {
    const pipe = new UniquePipePipe();
    expect(pipe).toBeTruthy();
  });
});
