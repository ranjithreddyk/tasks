import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'uniquePipe'
})
export class UniquePipePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return null;
  }

}
