# Chess Game

[Play the demo](http://livechess.herokuapp.com)
This game is made with [NodeJS](http://nodejs.org/) and Websockets(socket.io) for a real time chess game.

At the moment, it is in alpha and needs to have a lot of testing before I can confidently say it is robust.

My intention is to make the game portable and be created from calling one Javascript function and including one CSS stylesheet. Therefore it would allow others to embed this game. I also want to make it customizable (appearance, size, etc.) however it is a long way from that.
